import express from 'express';

const app = express();
app.use(express.json());

const SLACK_BOT_TOKEN = process.env.SLACK_BOT_TOKEN;
const SLACK_CHANNEL = process.env.JARVIS_SLACK_CHANNEL || '#jarvis';

async function sendSlack(text, channel = SLACK_CHANNEL) {
  if (!SLACK_BOT_TOKEN) {
    console.log(`[slack] No token — would send to ${channel}:`, text.slice(0, 80));
    return { ok: false, error: 'no_token' };
  }
  try {
    const r = await fetch('https://slack.com/api/chat.postMessage', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${SLACK_BOT_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ channel, text })
    });
    return r.json();
  } catch (e) {
    console.error('[slack] Send failed:', e.message);
    return { ok: false, error: e.message };
  }
}

// POST /slack/send — generic message
app.post('/slack/send', async (req, res) => {
  const { text, channel } = req.body;
  if (!text) return res.status(400).json({ error: 'text required' });
  const result = await sendSlack(text, channel);
  res.json(result);
});

// POST /slack/report — structured platform audit report
app.post('/slack/report', async (req, res) => {
  const { platform, status, issues = [], fixed = [], health_score } = req.body;

  const emoji = status === 'healthy' ? '✅' : status === 'warning' ? '⚠️' : '🔴';
  const score = health_score != null ? ` | Score: ${health_score}/100` : '';

  let text = `${emoji} *${(platform || 'UNKNOWN').toUpperCase()} AUDIT REPORT*${score}\n`;
  text += `Status: ${status || 'unknown'}\n`;
  text += `Issues found: ${issues.length} | Fixed: ${fixed.length}\n`;

  if (issues.length > 0) {
    text += `\n*Open issues:*\n`;
    text += issues.slice(0, 10).map(i => `• ${String(i).slice(0, 120)}`).join('\n');
    if (issues.length > 10) text += `\n_...and ${issues.length - 10} more_`;
  }

  if (fixed.length > 0) {
    text += `\n\n*Fixed this session:*\n`;
    text += fixed.slice(0, 5).map(f => `✓ ${String(f).slice(0, 120)}`).join('\n');
  }

  const result = await sendSlack(text);
  res.json(result);
});

// POST /slack/alert — urgent alert
app.post('/slack/alert', async (req, res) => {
  const { platform, message, level = 'warning' } = req.body;
  const emoji = level === 'critical' ? '🚨' : '⚠️';
  const text = `${emoji} *JARVIS ALERT — ${(platform || '').toUpperCase()}*\n${message}`;
  const result = await sendSlack(text);
  res.json(result);
});

// POST /slack/events — receive commands from Slack
app.post('/slack/events', async (req, res) => {
  const { type, challenge, event } = req.body;

  if (type === 'url_verification') return res.json({ challenge });
  res.json({ ok: true });

  if (!event) return;
  const text = (event.text || '').toLowerCase().replace(/<[^>]+>/g, '').trim();

  console.log(`[slack] Event: ${event.type} | Text: "${text.slice(0, 60)}"`);

  if (text.includes('status') || text.includes('health')) {
    try {
      const metrics = await fetch('http://127.0.0.1:9202/metrics/current').then(r => r.json());
      const memory = await fetch('http://127.0.0.1:9200/memory/summary').then(r => r.json());

      let msg = `📊 *JARVIS STATUS — ${new Date().toLocaleString('en-NZ', { timeZone: 'Pacific/Auckland' })}*\n`;
      msg += `Server: CPU ${metrics.cpu}% | RAM ${metrics.mem}% | Disk ${metrics.disk}%\n\n`;
      msg += `*Jarvis services:*\n`;
      Object.entries(metrics.jarvis || {}).forEach(([k, v]) => {
        msg += `${v === 'ONLINE' ? '✅' : '🔴'} ${k}: ${v}\n`;
      });
      msg += `\n*Platform health:*\n`;
      (memory.platforms || []).forEach(p => {
        const e = p.health_score > 80 ? '✅' : p.health_score > 50 ? '⚠️' : '🔴';
        msg += `${e} ${p.name}: ${p.status} (${p.health_score}/100)\n`;
      });
      if (memory.open_issues > 0) {
        msg += `\n⚠️ *${memory.open_issues} open unverified issues in memory*`;
      }
      await sendSlack(msg, event.channel);
    } catch (e) {
      await sendSlack(`❌ Status fetch failed: ${e.message}`, event.channel);
    }
    return;
  }

  if (text.includes('audit')) {
    const platforms = ['zoobicon', 'vapron', 'alecrae', 'marcoreid', 'gatetest'];
    const matched = platforms.find(p => text.includes(p));
    if (matched) {
      await sendSlack(`🔍 Starting ${matched} audit... reporting back shortly.`, event.channel);
      fetch('http://127.0.0.1:9204/audit/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ platform: matched })
      }).catch(e => console.error('[slack] Audit trigger failed:', e.message));
    } else {
      await sendSlack(`Which platform? Try: _audit zoobicon_ or _audit vapron_`, event.channel);
    }
    return;
  }

  if (text.includes('screenshot')) {
    const platforms = ['zoobicon', 'vapron', 'alecrae', 'marcoreid', 'gatetest'];
    const matched = platforms.find(p => text.includes(p));
    if (matched) {
      await sendSlack(`📸 Capturing ${matched} screenshots...`, event.channel);
      fetch('http://127.0.0.1:9201/screenshot/platform', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ platform: matched })
      }).catch(e => console.error('[slack] Screenshot trigger failed:', e.message));
    }
    return;
  }

  if (text.includes('help')) {
    const help = `*Jarvis commands:*\n` +
      `• _status_ — server + platform health\n` +
      `• _audit <platform>_ — run full audit\n` +
      `• _screenshot <platform>_ — capture screenshots\n\n` +
      `Platforms: zoobicon, vapron, alecrae, marcoreid, gatetest`;
    await sendSlack(help, event.channel);
  }
});

app.get('/slack/health', (req, res) => {
  res.json({ status: 'ok', token_configured: !!SLACK_BOT_TOKEN, channel: SLACK_CHANNEL });
});

const PORT = 9203;
app.listen(PORT, '127.0.0.1', () => {
  console.log(`[jarvis-slack] Running on http://127.0.0.1:${PORT}`);
  console.log(`[jarvis-slack] Token configured: ${!!SLACK_BOT_TOKEN}`);
});

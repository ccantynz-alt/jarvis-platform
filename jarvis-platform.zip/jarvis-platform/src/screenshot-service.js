import { spawn } from 'child_process';
import { writeFileSync, readFileSync, mkdirSync, readdirSync } from 'fs';
import { join } from 'path';
import express from 'express';

mkdirSync('/opt/jarvis/screenshots', { recursive: true });

const app = express();
app.use(express.json());

const SCREENSHOT_DIR = '/opt/jarvis/screenshots';
const CHROMIUM_BIN = process.env.CHROMIUM_BIN || detectChromium();

function detectChromium() {
  const { execSync } = await import('child_process');
  for (const bin of ['chromium-browser', 'chromium', 'google-chrome', 'google-chrome-stable']) {
    try {
      execSync(`which ${bin}`, { stdio: 'pipe' });
      return bin;
    } catch {}
  }
  return 'chromium-browser';
}

async function captureScreenshot(url, options = {}) {
  const {
    width = 1280,
    height = 900,
    waitMs = 4000,
    mobile = false
  } = options;

  const timestamp = Date.now();
  const safeName = url
    .replace(/https?:\/\//, '')
    .replace(/[^a-zA-Z0-9]/g, '_')
    .slice(0, 60);
  const filename = `${safeName}_${timestamp}.png`;
  const filepath = join(SCREENSHOT_DIR, filename);

  return new Promise((resolve, reject) => {
    const hardTimeout = setTimeout(() => {
      proc.kill('SIGKILL');
      reject(new Error(`Screenshot hard timeout (30s) for ${url}`));
    }, 30000);

    const args = [
      '--headless=new',
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--disable-software-rasterizer',
      '--single-process',
      '--no-zygote',
      '--run-all-compositor-stages-before-draw',
      `--window-size=${mobile ? '390' : width},${mobile ? '844' : height}`,
      `--screenshot=${filepath}`,
      `--virtual-time-budget=${waitMs}`,
    ];

    if (mobile) {
      args.push('--user-agent=Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15');
    }

    args.push(url);

    const proc = spawn(CHROMIUM_BIN, args, {
      stdio: ['pipe', 'pipe', 'pipe']
    });

    proc.on('close', () => {
      clearTimeout(hardTimeout);
      try {
        const data = readFileSync(filepath);
        if (data.length < 100) {
          reject(new Error(`Screenshot too small (${data.length} bytes) — likely blank`));
          return;
        }
        resolve({
          ok: true,
          filepath,
          filename,
          url,
          size: data.length,
          width: mobile ? 390 : width,
          height: mobile ? 844 : height,
          captured_at: new Date().toISOString(),
          base64: data.toString('base64'),
          mimeType: 'image/png'
        });
      } catch (e) {
        reject(new Error(`Screenshot file missing: ${e.message}`));
      }
    });

    proc.on('error', (err) => {
      clearTimeout(hardTimeout);
      reject(new Error(`Chromium spawn error: ${err.message}`));
    });
  });
}

// POST /screenshot/capture
app.post('/screenshot/capture', async (req, res) => {
  const { url, options } = req.body;
  if (!url) return res.status(400).json({ error: 'url required' });

  try {
    const result = await captureScreenshot(url, options || {});
    res.json(result);
  } catch (err) {
    console.error(`[screenshot] Failed for ${url}:`, err.message);
    res.status(500).json({ ok: false, error: err.message, url });
  }
});

// POST /screenshot/batch
app.post('/screenshot/batch', async (req, res) => {
  const { urls, options } = req.body;
  if (!urls?.length) return res.status(400).json({ error: 'urls array required' });

  const results = [];
  for (const url of urls.slice(0, 10)) {
    try {
      const r = await captureScreenshot(url, options || {});
      results.push({ url, ok: true, filepath: r.filepath, size: r.size, captured_at: r.captured_at });
    } catch (err) {
      results.push({ url, ok: false, error: err.message });
    }
  }

  res.json({
    results,
    captured: results.filter(r => r.ok).length,
    failed: results.filter(r => !r.ok).length
  });
});

// POST /screenshot/platform — screenshot all known platforms
app.post('/screenshot/platform', async (req, res) => {
  const PLATFORM_URLS = {
    zoobicon: ['https://zoobicon.com', 'https://zoobicon.com/builder'],
    vapron: ['https://vapron.ai'],
    alecrae: ['https://alecrae.com'],
    marcoreid: ['https://marcoreid.com'],
    gatetest: ['https://gatetest.ai'],
  };

  const { platform } = req.body;
  const urls = platform ? (PLATFORM_URLS[platform] || []) : Object.values(PLATFORM_URLS).flat();

  res.json({ ok: true, message: `Capturing ${urls.length} screenshots`, urls });

  // Run async
  for (const url of urls) {
    try {
      await captureScreenshot(url);
      console.log(`[screenshot] Captured: ${url}`);
    } catch (e) {
      console.error(`[screenshot] Failed: ${url} — ${e.message}`);
    }
  }
});

// GET /screenshot/list
app.get('/screenshot/list', (req, res) => {
  try {
    const files = readdirSync(SCREENSHOT_DIR)
      .filter(f => f.endsWith('.png'))
      .map(f => ({
        filename: f,
        path: join(SCREENSHOT_DIR, f),
        url_hint: f.replace(/_\d+\.png$/, '').replace(/_/g, '.')
      }))
      .slice(-100);
    res.json({ screenshots: files, count: files.length });
  } catch (e) {
    res.json({ screenshots: [], count: 0, error: e.message });
  }
});

// GET /screenshot/health
app.get('/screenshot/health', (req, res) => {
  res.json({
    status: 'ok',
    chromium_bin: CHROMIUM_BIN,
    screenshot_dir: SCREENSHOT_DIR,
    uptime: process.uptime()
  });
});

const PORT = 9201;
app.listen(PORT, '127.0.0.1', () => {
  console.log(`[jarvis-screenshot] Running on http://127.0.0.1:${PORT}`);
  console.log(`[jarvis-screenshot] Chromium: ${CHROMIUM_BIN}`);
});

# Jarvis Platform

Autonomous agent infrastructure for MarcoReid Intelligence Systems.

Monitors and repairs: Zoobicon · Vapron · AlecRae · MarcoReid · GateTest

## Install on server

```bash
git clone https://github.com/ccantynz-alt/jarvis-platform /opt/jarvis
cd /opt/jarvis
bash scripts/install.sh
```

## Every Claude Code session

```bash
# START
bash /opt/jarvis/scripts/session-start.sh zoobicon

# END
bash /opt/jarvis/scripts/session-end.sh zoobicon <session_id> "what you did"
```

## Services

| Service | Port | Purpose |
|---------|------|---------|
| jarvis-memory | 9200 | SQLite cross-session memory |
| jarvis-screenshot | 9201 | CDP screenshot capture |
| jarvis-metrics | 9202 | Real metrics + WebSocket |
| jarvis-slack | 9203 | Slack command bridge |
| jarvis-audit | 9204 | Build + test audit runner |

## Docs

See `CLAUDE.md` for full operating doctrine.
